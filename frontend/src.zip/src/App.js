import { Container } from '@mui/material';
import './App.css';
import MenuAppBar from '../../course-app2/src/component/header';
import HomePage from '../../course-app2/src/component/homePage';

function App() {
  return (
    <>
      <Container>
        <MenuAppBar />
        <HomePage />
      </Container >
    </>
  );
}

export default App;
