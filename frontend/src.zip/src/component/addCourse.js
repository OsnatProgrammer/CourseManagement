import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import IconButton from '@mui/material/IconButton';
import { Add } from '@mui/icons-material';
import data from '../data.json';

// import  useStyles  from './style'; 
// import { makeStyles } from '@material-ui/core'


// const useStyles = makeStyles({

//     center: {
//         textAlign: 'center',
//         display: 'flex',
//         flexDirection: 'column',
//         alignItems: 'center',
//     }
// });


export default function AddCourse() {

    const [courselist, setCourselist] = useState([data])
    const [courseDate, setCourseDate] = useState('');
    const [courseName, setCourseName] = useState('');

    
    const handleCourseDateChange = (event) => {
        setCourseDate(event.target.value);
    };

    const handleCourseNameChange = (event) => {
        setCourseName(event.target.value);
    };

    const AddCourse = () => {
        if (courseDate.trim() !== '' && courseName.trim() !== '') {
            const newCourse = {
                courseDate,
                courseName
            }
            setCourselist([...courselist, newCourse]);
            setCourseDate('');
            setCourseName('');
        }
        // else if () {

        // }
    };


    // const classes = useStyles();

    return (
        <Grid container spacing={3} justifyContent="center" alignItems="center" >
            <Grid item>
                <IconButton color="primary" aria-label="add to shopping cart" onClick={AddCourse}>
                    <Add />
                </IconButton>
            </Grid>

            <Grid item>
                <TextField
                    className="center"
                    id="courseDate"
                    label="...תאריך"
                    variant="standard"
                    value={courseDate}
                    onChange={handleCourseDateChange}
                />
            </Grid>
            <Grid item >

                <TextField
                    // className={classes.center}
                    className="center"
                    id="courseName"
                    label="...שם הקורס"
                    variant="standard"
                    // helperText=error
                    value={courseName}
                    onChange={handleCourseNameChange}

                />
            </Grid>
        </Grid>
    );
}
