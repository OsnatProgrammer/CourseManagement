import React from 'react';
import AddCourse from './addCourse';
// import { Typography } from '@mui/material';
import ItemList from './itemList';


export default function HomePage() {

    const [courselist, setCourselist] = useState([data])


    return (
        <div>
            <h1 align='center'>רישום לקורסים</h1>
            <AddCourse />
            <ItemList/>
        </div>
    )
}
