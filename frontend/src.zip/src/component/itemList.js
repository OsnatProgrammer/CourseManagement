import React, { useState } from 'react'
import data from '../data.json';
import { Divider, List, ListItem, ListItemText } from '@mui/material';


export default function ItemList() {

    const [courselist, setCourselist] = useState([data])

    // useEffect(() => {
    //     setCourselist(data);
    // });

    return (

        <div>
            <List className='center'
                sx={{
                    width: '100%',
                    maxWidth: 360,
                    bgcolor: 'background.paper',
                    position: 'relative',
                    overflow: 'auto',
                    maxHeight: 300,
                    '& ul': { padding: 0 },
                }}
            >

                {/* <List
        className='center'
        sx={{
          width: '100%',
          maxWidth: 360,
          bgcolor: 'background.paper',
          position: 'relative',
          overflow: 'auto',
          maxHeight: 300,
          '& ul': { padding: 0 },
        }}
      > */}

                {courselist[0].map((item) => {
                    return (
                        <div key={item.profile.ID}>
                            <ListItem>
                                <ListItemText
                                    primary={item.courseName}
                                    secondary={item.courseDate}
                                />
                            </ListItem>
                            <Divider variant="inset" component="li" />
                        </div>
                    );
                })}
            </List>
        </div>
    )
}


